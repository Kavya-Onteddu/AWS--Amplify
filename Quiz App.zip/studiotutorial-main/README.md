
## Welcome

This is a repo for a tutorial for AWS Amplify Studio! To get started run amplify init.