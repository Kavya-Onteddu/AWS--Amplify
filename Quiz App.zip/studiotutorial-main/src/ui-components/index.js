/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

export { default as studioTheme } from "./studioTheme";
export { default as QuestionCreateForm } from "./QuestionCreateForm";
export { default as QuestionUpdateForm } from "./QuestionUpdateForm";
export { default as AnswerCreateForm } from "./AnswerCreateForm";
export { default as AnswerUpdateForm } from "./AnswerUpdateForm";
